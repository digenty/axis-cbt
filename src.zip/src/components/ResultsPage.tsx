"use client";

import { useCBTStore } from "@/store";
import { use } from "react";
import { BackButton } from "./PageHeader";
import { ResultsView } from "./ResultsView";

export default function ResultsPage({
	params,
}: {
	params: Promise<{ classId: string; subjectId: string }>;
}) {
	const { classId, subjectId } = use(params);
	const cls = useCBTStore((s) => s.classes.find((c) => c.id === classId));
	const subject = useCBTStore((s) =>
		s.subjects.find((sub) => sub.id === subjectId),
	);

	return (
		<div>
			<BackButton href={`/classes/${classId}/subjects/${subjectId}`} />
			<ResultsView
				subjectId={subjectId}
				classId={classId}
				className={cls?.name || classId}
				subjectName={subject?.name || subjectId}
			/>
		</div>
	);
}
