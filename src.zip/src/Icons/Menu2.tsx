import { SVGProps } from "react";

const Menu2 = (props: SVGProps<SVGSVGElement>) => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M2.5 3.33301H17.5V4.99967H2.5V3.33301ZM2.5 9.16634H12.5V10.833H2.5V9.16634ZM2.5 14.9997H17.5V16.6663H2.5V14.9997Z" fill={props.fill} />
  </svg>
);

export default Menu2;
