import GradeAttemptView from "@/components/GradeAttemptView";

const GradeAttemptViewPage = ({
	params,
}: Readonly<{
	params: Promise<{ classId: string; subjectId: string; attemptId: string }>;
}>) => {
	return <GradeAttemptView params={params} />;
};

export default GradeAttemptViewPage;
