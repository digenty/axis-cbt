import api from "@/lib/axios-auth";
import { isAxiosError } from "axios";

export type CbtQueBankTopicPayload = {
	name: string;
	classId: number;
	subjectId: number;
	branchId: number;
	description: string;
	displayOrder: number;
	id?: number;
};

export type CbtQuestion = {
	classId: number;
	subjectId: number;
	topicId: number;
	questionText: string;
	questionHtml: string;
	imageUrl: string;
	marks: number;
	explanation: string;
	difficultyLevel: string;
	typeSpecificData: {
		type: string;
		minWords: number;
		maxWords: number;
		modelAnswer: string;
		rubric: string;
	};
};

export const getCbtQuestionBankTopics = async (payload: {
	classId?: number;
	subjectId?: number;
}) => {
	try {
		const { data } = await api.get(
			`/api/cbt/question-bank/topics?classId=${payload?.classId}&subjectId=${payload?.subjectId}`,
		);
		return data;
	} catch (error: unknown) {
		if (isAxiosError(error)) {
			throw error.response?.data;
		}
		throw error;
	}
};

export const addCbtQuestionBankTopics = async (
	payload: CbtQueBankTopicPayload,
) => {
	try {
		const { data } = await api.post("/api/cbt/question-bank/topics", payload);
		return data;
	} catch (error: unknown) {
		if (isAxiosError(error)) {
			throw error.response?.data;
		}
		throw error;
	}
};

export const getCbtQuestions = async (payload: {
	classId?: number;
	subjectId?: number;
}) => {
	try {
		const { data } = await api.get(
			`/api/cbt/question-bank/questions/classes/${payload?.classId}/subjects/${payload?.subjectId}`,
		);
		return data;
	} catch (error: unknown) {
		if (isAxiosError(error)) {
			throw error.response?.data;
		}
		throw error;
	}
};

export const addCbtQuestion = async (payload: CbtQuestion) => {
	try {
		const { data } = await api.post(
			"/api/cbt/question-bank/questions",
			payload,
		);
		return data;
	} catch (error: unknown) {
		if (isAxiosError(error)) {
			throw error.response?.data;
		}
		throw error;
	}
};
